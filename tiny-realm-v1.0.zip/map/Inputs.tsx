<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Inputs" tilewidth="8" tileheight="8" tilecount="1380" columns="30">
 <image source="../images/Inputs.png" width="240" height="368"/>
</tileset>
