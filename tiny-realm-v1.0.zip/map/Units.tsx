<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Units" tilewidth="8" tileheight="8" tilecount="8658" columns="111">
 <image source="../images/Units.png" width="888" height="624"/>
 <tile id="447">
  <animation>
   <frame tileid="447" duration="100"/>
   <frame tileid="448" duration="100"/>
   <frame tileid="449" duration="100"/>
  </animation>
 </tile>
</tileset>
