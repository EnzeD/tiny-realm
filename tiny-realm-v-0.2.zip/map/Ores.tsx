<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ores" tilewidth="8" tileheight="8" tilecount="624" columns="26">
 <image source="../../../Users/zullo/Downloads/Mini-Medieval-v2.1/Mini-Medieval-8x8/Ores.png" width="208" height="192"/>
</tileset>
