<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Interface" tilewidth="8" tileheight="8" tilecount="180" columns="9">
 <image source="../images/Interface.png" width="72" height="160"/>
</tileset>
