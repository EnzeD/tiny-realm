<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ores" tilewidth="8" tileheight="8" tilecount="624" columns="26">
 <image source="../images/Ores.png" width="208" height="192"/>
 <tile id="98">
  <animation>
   <frame tileid="98" duration="200"/>
   <frame tileid="99" duration="200"/>
   <frame tileid="100" duration="200"/>
   <frame tileid="101" duration="200"/>
   <frame tileid="102" duration="200"/>
   <frame tileid="103" duration="200"/>
  </animation>
 </tile>
 <tile id="410">
  <animation>
   <frame tileid="410" duration="200"/>
   <frame tileid="411" duration="200"/>
   <frame tileid="412" duration="200"/>
   <frame tileid="413" duration="200"/>
   <frame tileid="414" duration="200"/>
   <frame tileid="415" duration="200"/>
  </animation>
 </tile>
</tileset>
