<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Crops" tilewidth="8" tileheight="8" tilecount="480" columns="24">
 <image source="../images/Crops.png" width="192" height="160"/>
</tileset>
