<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Walls" tilewidth="8" tileheight="8" tilecount="1392" columns="29">
 <image source="../images/Walls.png" width="232" height="384"/>
</tileset>
